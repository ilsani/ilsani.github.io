﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebSite.Vulnerable.Models
{
    public class ControllerResponse
    {
        public ControllerResponse(User user)
        {
            this.user = user;
        }

        private readonly User user;

        public User User
        {
            get { return user; }
        }
    }
}
