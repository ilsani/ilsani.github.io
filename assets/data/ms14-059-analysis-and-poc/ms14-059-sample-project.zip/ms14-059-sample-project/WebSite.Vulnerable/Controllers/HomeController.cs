﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebSite.Vulnerable.Controllers
{
    public class HomeController : Controller
    {
        // http://localhost:54606/Home/Index?firstCity=<script>alert(1)</script>

        [ValidateInput(false)]
        public ActionResult Index(string firstCity)
        {
            String username = "bob";

            var addresses = new List<Models.Address>();
            addresses.Add(new Models.Address(firstCity, "Italy"));
            addresses.Add(new Models.Address("Berlin", "Germany"));

            var model = new Models.User(username, addresses);

            return View(model);
        }
    }
}