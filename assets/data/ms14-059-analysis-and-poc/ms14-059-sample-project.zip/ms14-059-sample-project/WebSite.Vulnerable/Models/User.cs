﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebSite.Vulnerable.Models
{
    public class User
    {
        public User() { }

        public User(String username, IEnumerable<Address> addresses)
        {
            this.Username = username;
            this.Addresses = addresses;
        }

        public IEnumerable<Address> Addresses
        {
            get;
            private set;
        }

        public String Username
        {
            get;
            private set;
        }

    }
}
